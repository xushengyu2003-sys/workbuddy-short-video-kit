# Windows 环境检查与测试

本包是 0.2.3-windows-test.3；Windows WorkBuddy 实机验收待完成。技能包不含 Python、FFmpeg、字体或转录模型。下面由 WorkBuddy 执行，用户不必手动敲命令。安装入口以用户当前 WorkBuddy 界面为准，不猜版本按钮。

## 环境与路径

1. 先运行下方 PowerShell 检测入口，即使未安装 Python 也能出 bootstrap.json。引擎要求 Python 3.9+；先检查 WorkBuddy 已有 Python 环境，再检查其他已安装解释器。这台电脑成功使用 Python 3.13.14，但这只是一次实测版本，不要求其他人照装。`py -3` 只是可选发现入口；没有 py 就用已找到的 python.exe。WindowsApps 的占位入口不算已安装解释器。
2. 先选用户可写项目目录，建议短路径，例如 `D:/WBVideo/项目01`，中文路径可以试用，但报错时先核对路径与 JSON 转义。若 WorkBuddy 已提供可用的隔离 Python 环境，优先检查并复用；缺依赖时先确认该环境是否属于当前技能/任务，避免把包装进系统 Python 或其他技能环境。没有合适的隔离环境时，才在项目下创建 `.venv/Scripts/python.exe`；不需要 Activate.ps1，也不用更改执行策略。安装依赖与运行工具必须用同一个 python.exe。
3. FFmpeg 与 ffprobe：优先复用已安装的工具；支持 PATH、环境变量 WB_FFMPEG/WB_FFPROBE，或把用户已取得的两个 exe 放入技能的 bin/。这台电脑采用技能目录 `bin/ffmpeg.exe` 和 `bin/ffprobe.exe`，未改全局 PATH；若技能目录不可写或更新会替换内容，放到稳定的用户目录并设置两个 WB_ 变量。从 https://ffmpeg.org/download.html 的 Windows 入口取得构建，不运行不明安装脚本。本包不下载二进制。doctor 的 h264_encoder 要为 true；Windows 使用 libx264。两个工具应来自同一构建。
4. 中文硬字幕依赖 Pillow：在项目环境安装 `Pillow>=10,<13`。字体按 WB_FONT/清单 font 优先，其次查 WINDIR/Fonts 中 msyh.ttc、msyhbd.ttc、simhei.ttf；不存在则指定已有中文 TTF/OTF/TTC。能找到文件不代表所有字都有字形，必须看字幕抽帧。
5. 新素材需要词级转录时，按需安装 `faster-whisper>=1.1,<2`。CPU/int8、small 是默认；可用本地模型目录。首次联网下载模型需说明并获得用户同意后加 --allow-model-download；安装依赖也需要网络。模型失败时保留错误，可复用经核验的词级转录，不按字数伪造时间轴。只有 SRT 时可做整段剪辑与字幕，但不能声称完成词级精剪。

## 先检测，再引导安装

让 WorkBuddy 在 PowerShell 中执行技能自带的脚本。只需技能路径和新的报告目录；没有 Python 也能发现缺项。口播需要自动转录时使用 `-RequireTranscription`。指定已有解释器可加 `-PythonPath`。

```powershell
$SkillDir = "D:/技能/workbuddy-short-video-windows"
$ProjectDir = "D:/WBVideo/项目01"
& "$SkillDir/scripts/check-windows.ps1" -ReportDir "$ProjectDir/environment-v1" -RequireTranscription
```

检查结果在 bootstrap.json；找到可用 Python 时还有 environment.json。environment.json 的 ready=true 才能继续；blocking 中列出缺项和 repair_steps。PowerShell 不能执行脚本时，让 WorkBuddy 读取脚本并在其已有终端权限内逐步执行同样的只读检查；不要要求用户放宽全局执行策略。**安装或补齐依赖后换 `environment-v2` 复检。** 模型未下载时只引导用户取得模型或同意首次下载；检测脚本本身不下载。

| 缺项 | 下载与安装指引 | 复检依据 |
|---|---|---|
| Python | 先让 WorkBuddy 找自己的隔离环境；没有可用解释器时，再打开 [Python 官方 Windows 下载页](https://www.python.org/downloads/windows/)，选适合本机架构、且不低于 3.9 的版本，安装 pip；已有 Python 可直接传 `-PythonPath`。 | bootstrap.json 中 python 有路径；environment.json 中 python.ok=true。 |
| FFmpeg / ffprobe | 打开 [FFmpeg 下载页](https://ffmpeg.org/download.html) 的 Windows EXE Files 区，进入其列出的 [gyan.dev Windows 构建](https://www.gyan.dev/ffmpeg/builds/) 等下载页；解压后在同一 bin 文件夹找 ffmpeg.exe 和 ffprobe.exe。可放技能的 bin/（若可写且易保留），或放用户目录并设置 WB_FFMPEG/WB_FFPROBE；不必修改系统 PATH。 | 两项 ok=true，h264_aac.ok=true。 |
| Pillow | 看 [Pillow 项目包页](https://pypi.org/project/Pillow/)；在本项目 Python 环境运行 `& $Py -m pip install "Pillow>=10,<13"`。 | Pillow.ok=true，显示实际版本。 |
| faster-whisper | 只有自动词级转录才需要。看 [faster-whisper 项目包页](https://pypi.org/project/faster-whisper/)；在同一环境运行 `& $Py -m pip install "faster-whisper>=1.1,<2"`。 | faster_whisper.ok=true。 |
| 转录模型 | 已有模型目录可在检测时通过 `-Model` 指向它；否则告诉用户首次模型下载需要网络与磁盘空间，取得同意后由转录步骤下载。 | transcription_model.ok=true。 |
| 中文字体 | 优先检查系统 `WINDIR/Fonts`；若缺少，使用电脑已有、可合法使用的中文 TTF/OTF/TTC 文件，设置 WB_FONT 为其路径。 | chinese_font.ok=true，并查看最终字幕抽帧。 |

Python 命令参数用独立参数传入；路径含空格用引号；不要拼接到 shell 字符串。以下是缺项修复示例，使用检测出的实际 Python 路径。

```powershell
$SkillDir = 'D:/技能/workbuddy-short-video-windows'
$ProjectDir = 'D:/WBVideo/项目01'
$HostPython = 'C:/实际Python目录/python.exe'
New-Item -ItemType Directory -Force -Path $ProjectDir | Out-Null
& $HostPython -m venv "$ProjectDir/.venv"
if ($LASTEXITCODE -ne 0) { throw '创建环境失败' }
$Py = "$ProjectDir/.venv/Scripts/python.exe"
& $Py -m pip install 'Pillow>=10,<13'
if ($LASTEXITCODE -ne 0) { throw '安装 Pillow 失败' }
# 需要转录才安装：
# & $Py -m pip install 'faster-whisper>=1.1,<2'
# 工具不在 PATH 时，指定真实文件；变量值不带额外嵌套引号：
# $env:WB_FFMPEG = 'D:/工具/ffmpeg/bin/ffmpeg.exe'
# $env:WB_FFPROBE = 'D:/工具/ffmpeg/bin/ffprobe.exe'
$Engine = "$SkillDir/scripts/video.py"
$Editor = "$SkillDir/scripts/editorial.py"
& $Py $Engine doctor
```

在新建虚拟环境后再次运行 check-windows.ps1，并传 `-PythonPath $Py`，保证检查的是最终运行环境。check_environment.py 实际尝试导入 Pillow/faster-whisper、加载本地转录模型，且用 FFmpeg 编码合成片段。pip/venv 缺失会在 install_support_missing 中报告；如果需要创建环境，应先修复它们。记录 environment.json 中的 runtime_python。子进程文本和命令 JSON 使用 UTF-8；PowerShell 重定向的默认编码随版本不同，保存 JSON 推荐使用引擎的 --out，或捕获文本后用明确 UTF-8 写文件。JSON 中路径推荐正斜杠；反斜杠须双写。


## 网络慢或访问失败时

先区分是 Python 包下载慢，还是转录模型下载失败。不要让 pip 无期限等待；保留超时信息，换一次已知可用的下载入口，然后复检。下面记录的是用户这台电脑的实测方案，不保证别的网络也可用。

- pip 直连曾长时间无响应。可仅对这次安装加 `--index-url https://mirrors.aliyun.com/pypi/simple/`，见 [阿里云 PyPI 镜像说明](https://developer.aliyun.com/mirror/pypi)。例：`& $Py -m pip install --index-url https://mirrors.aliyun.com/pypi/simple/ 'Pillow>=10,<13' 'faster-whisper>=1.1,<2'`。这一参数只作用于当前命令，不改用户的全局 pip 配置。若镜像包不可用或校验失败，回到 PyPI 官方源或让用户选其他可信来源。
- Hugging Face 直连在这台电脑不可用。取得用户同意后，可以只在当前 PowerShell 会话设置 `$env:HF_ENDPOINT = 'https://hf-mirror.com'` 再下载模型。这个地址是第三方镜像，[镜像站说明](https://hf-mirror.com/)提供相同设置方法；不要把它当作 Hugging Face 官方域名，也不要向镜像发送私有模型令牌。优先复用已经存在的本地模型缓存。镜像不可用时停止并报告，不循环重试。
- 从 [FFmpeg 项目下载页](https://ffmpeg.org/download.html) 进入它列出的 Windows 构建站点；这台电脑从 gyan.dev 取得构建。下载完确认 ffmpeg.exe、ffprobe.exe 属于同一套文件，检查实际版本与 H.264/AAC 编码能力。
- 转录包会带入 CTranslate2、ONNX Runtime、PyAV、tokenizers、huggingface-hub 等依赖，通常由 pip 自动解析。截图上的 1.2.1、4.8.2、1.31.0 是这台机器当时的版本记录，不应逐项固定安装或要求版本完全一致。转录模型与 faster-whisper 程序包是两件东西：包安装成功仍可能缺模型。

首次模型下载前，向用户说明大致下载量和本机保存位置。截图显示这台电脑的 small 模型约 464 MB；具体体积以实际模型仓库为准。用户同意后，用同一个解释器准备模型，再换新报告目录复检。`HF_ENDPOINT` 只在本次需要镜像时设置；不设置则使用默认 Hugging Face 地址。

```powershell
# 只有用户同意下载模型后执行；如需镜像，先在当前终端设置：
# $env:HF_ENDPOINT = 'https://hf-mirror.com'
& $Py "$SkillDir/scripts/prepare_model.py" --model small --allow-download --out "$ProjectDir/model-download-v1.json"
& "$SkillDir/scripts/check-windows.ps1" -ReportDir "$ProjectDir/environment-v2" -PythonPath $Py -RequireTranscription
```

若下载后模型文件已在缓存，复检时应能从本地加载，不重复下载；失败则保留 model-download-v1.json 中的错误。

## 三阶段 Windows 测试

环境检测 ready=true 后，再阅读 [engine.md](engine.md) 和 [editing.md](editing.md)，执行时不要照抄其中 POSIX 示例路径。

### 1. 合成素材测试（无需用户视频、模型或网络）

```powershell
& $Py "$SkillDir/scripts/selftest.py" --out "$ProjectDir/selftest-v1"
```

输出 doctor.json、selftest.json、tests.txt。测试包括带中文/空格/特殊字符的路径、裁切拼接、静音检测、中文字幕、字幕时间轴、缓存改字幕、图片/BGM与标题装饰、原片不变和拒绝覆盖。失败返回 1；缺依赖返回 2；通过返回 0。报告写的是运行机器的平台；macOS 上通过不能当 Windows 通过。测试过程中生成的合成媒体在临时目录，结束后清理；保留日志。

### 2. 真实素材与转录

选择用户给的一段 30–120 秒口播；先 probe 和转录再选段。模型可用且获准下载时才用对应开关：

```powershell
& $Py $Engine probe 'D:/视频素材/口播 测试.mp4'
& $Py $Engine transcribe 'D:/视频素材/口播 测试.mp4' --out "$ProjectDir/transcript" --model small
& $Py $Engine silence 'D:/视频素材/口播 测试.mp4' --out "$ProjectDir/silence.json" --minimum 0.35 --padding 0.12
& $Py $Editor analyze 'D:/视频素材/口播 测试.mp4' "$ProjectDir/transcript/transcript.json" --mode tight --silence "$ProjectDir/silence.json" --out "$ProjectDir/proposals.json"
& $Py $Editor review "$ProjectDir/proposals.json" --out "$ProjectDir/review.md"
```

WorkBuddy 阅读全文，写 decisions.json，然后 build、校对 phrases.json、captions、预览并更新清单：encoder=libx264，subtitles 指向最终 output SRT、subtitle_timing=output、画幅按 brief。再 validate/render。每条命令失败即检查错误，不在失败产物上继续；具体命令与数据格式见 engine.md。

### 3. 成片与返工

确认 final.mp4 存在、可播放，quality.json.machine_pass=true。检查实际首/中/尾帧、中文是否为方块、字幕两行和人物遮挡；试听切口。仅改字幕时 restyle，核实 reused_base=true。无法听音则记 pending，由用户试听。

交付测试报告：Windows 版本、WorkBuddy 版本（可读到才填写）、Python/FFmpeg/字体/模型、测试计数、真实片原/新时长、输出绝对路径、失败原文及处理、机器检查/画面检查/试听各自状态。不要写“已兼容”来替代证据。

## 排错

- 找不到工具：确认技能 bin/ 内两个 exe 或指定两个真实路径，重跑 check-windows.ps1；不要用 brew。
- 找不到字体/方块字：指定中文字体、检查预览；不分发系统字体。
- 转录安装/DLL/模型失败：保存异常，按实际错误修复；不默认安装 CUDA。本版 CPU 转录。
- 输出目录已存在：用 out-v2 或 selftest-v2；不删除旧成果来重试。
- 路径报错：检查 JSON 转义及绝对路径；不要移走原素材。网络共享或超长路径失败时，可经授权复制至短的本地工作目录后重试。
- 报告缺失或脚本失败：不能宣称通过。针对明确问题最多修复两次，交付已取得的诊断。
