"""Run portable synthetic-media tests and save a report; no downloads."""
import argparse
import io
import platform
from pathlib import Path
import sys
import unittest
import video


def main():
    video.configure_console()
    parser = argparse.ArgumentParser(description='Windows WorkBuddy synthetic editing test')
    parser.add_argument('--out', required=True, help='New report directory')
    args = parser.parse_args()
    out = Path(args.out).expanduser().resolve()
    if out.exists():
        parser.error('Report directory already exists; choose a new version')
    out.mkdir(parents=True)
    environment = video.doctor()
    video.write_json(out/'doctor.json', environment)
    ready = (all('path' in environment['tools'][x] for x in ['ffmpeg', 'ffprobe'])
             and environment.get('h264_encoder')
             and environment['optional']['PIL'] and environment['font'])
    if not ready:
        video.write_json(out/'selftest.json', {'status': 'blocked', 'reason': 'Missing dependencies; see doctor.json'})
        return 2
    log = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(Path(__file__).parent/'tests'))
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (out/'tests.txt').write_text(log.getvalue(), encoding='utf-8')
    report = {'status': 'passed' if result.wasSuccessful() and result.testsRun and not result.skipped else 'failed',
              'platform': platform.platform(), 'tests': result.testsRun,
              'failures': len(result.failures), 'errors': len(result.errors),
              'skipped': len(result.skipped), 'real_media_review': 'pending',
              'transcription_model_test': 'pending'}
    video.write_json(out/'selftest.json', report)
    print(log.getvalue())
    print('Report: ' + str(out/'selftest.json'))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
