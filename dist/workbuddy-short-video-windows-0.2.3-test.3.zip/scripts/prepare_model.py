"""Explicitly download and load a faster-whisper model after user consent."""
import argparse
import json
from pathlib import Path
import sys
import video


def main():
    video.configure_console()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', default='small')
    parser.add_argument('--allow-download', action='store_true')
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    out = Path(args.out).expanduser().resolve()
    if out.exists():
        parser.error('Report exists; choose a new path')
    if not args.allow_download:
        parser.error('Download requires explicit --allow-download after informing the user')
    try:
        from faster_whisper import WhisperModel
        WhisperModel(args.model, device='cpu', compute_type='int8',
                     cpu_threads=2, local_files_only=False)
        report = {'ok': True, 'model': args.model, 'python': sys.executable,
                  'next': 'Rerun check-windows.ps1 with -RequireTranscription in a new report directory'}
        code = 0
    except Exception as e:
        report = {'ok': False, 'model': args.model, 'python': sys.executable,
                  'error': str(e), 'next': 'Check the network, source and disk space; retain this report'}
        code = 2
    video.write_json(out, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return code


if __name__ == '__main__':
    sys.exit(main())
