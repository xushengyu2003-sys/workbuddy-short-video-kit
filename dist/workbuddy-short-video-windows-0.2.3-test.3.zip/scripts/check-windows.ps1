# No Python required to start. Does not install or download anything.
param(
    [Parameter(Mandatory=$true)][string]$ReportDir,
    [string]$PythonPath,
    [switch]$RequireTranscription,
    [string]$Model = 'small'
)
$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $ReportDir) { throw 'Report directory exists; choose a new version.' }
$null = New-Item -ItemType Directory -Path $ReportDir
$ReportDir = (Resolve-Path -LiteralPath $ReportDir).Path
$utf8 = New-Object System.Text.UTF8Encoding($false)
$osInfo = [Environment]::OSVersion.VersionString
$candidates = @()
if ($PythonPath) {
    $candidates += [PSCustomObject]@{path=$PythonPath; arguments=@()}
} else {
    # Prefer an existing WorkBuddy-managed environment when it is usable.
    if ($env:USERPROFILE) {
        $wbEnvs = "$env:USERPROFILE/.workbuddy/binaries/python/envs"
        $wbDefault = Join-Path $wbEnvs 'default/Scripts/python.exe'
        if (Test-Path -LiteralPath $wbDefault -PathType Leaf) {
            $candidates += [PSCustomObject]@{path=$wbDefault; arguments=@()}
        }
        foreach ($file in @(Get-ChildItem -Path "$wbEnvs/*/Scripts/python.exe" -ErrorAction SilentlyContinue | Sort-Object FullName)) {
            if ($file.FullName -ne $wbDefault) {
                $candidates += [PSCustomObject]@{path=$file.FullName; arguments=@()}
            }
        }
    }
    foreach ($name in @('py','python','python3')) {
        $cmd = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($cmd -and $cmd.Source -notmatch '[\\/]WindowsApps[\\/]') {
            $prefix = @()
            if ($name -eq 'py') { $prefix = @('-3') }
            $candidates += [PSCustomObject]@{path=$cmd.Source; arguments=$prefix}
        }
    }
    $patterns = @()
    if ($env:LOCALAPPDATA) { $patterns += "$env:LOCALAPPDATA/Programs/Python/Python*/python.exe" }
    if ($env:ProgramFiles) { $patterns += "$env:ProgramFiles/Python*/python.exe" }
    foreach ($pattern in $patterns) {
        foreach ($file in @(Get-ChildItem -Path $pattern -ErrorAction SilentlyContinue | Sort-Object FullName -Descending)) {
            $candidates += [PSCustomObject]@{path=$file.FullName; arguments=@()}
        }
    }
}
$attempts = @()
$selected = $null
foreach ($candidate in $candidates) {
    try {
        $probeArgs = @($candidate.arguments) + @('-c','import json,sys; print(json.dumps(dict(path=sys.executable,version=list(sys.version_info[:3]),usable=sys.version_info>=(3,9))))')
        $raw = & $candidate.path @probeArgs 2>$null
        if ($LASTEXITCODE -eq 0) {
            $probe = ($raw -join "`n") | ConvertFrom-Json
            $attempts += [PSCustomObject]@{candidate=$candidate.path; result=$probe}
            if ($probe.usable) { $selected = $probe.path; break }
        } else { $attempts += [PSCustomObject]@{candidate=$candidate.path; error='Python probe failed'} }
    } catch { $attempts += [PSCustomObject]@{candidate=$candidate.path; error=$_.Exception.Message} }
}
$tools = @{}
foreach ($name in @('ffmpeg','ffprobe')) {
    $override = [Environment]::GetEnvironmentVariable('WB_' + $name.ToUpper())
    $cmd = Get-Command $name -CommandType Application -ErrorAction SilentlyContinue | Select-Object -First 1
    $local = Join-Path (Split-Path -Parent $PSScriptRoot) "bin/$name.exe"
    $found = $null
    if ($override) { $found = $override }
    elseif ($cmd) { $found = $cmd.Source }
    elseif (Test-Path -LiteralPath $local -PathType Leaf) { $found = $local }
    $tools[$name] = @{path=$found; file_exists=([bool]($found -and (Test-Path -LiteralPath $found -PathType Leaf)))}
}
$fonts = @()
if ($env:WB_FONT) { $fonts += $env:WB_FONT }
if ($env:WINDIR) { foreach ($file in @('msyh.ttc','msyhbd.ttc','simhei.ttf')) { $fonts += "$env:WINDIR/Fonts/$file" } }
$foundFonts = @($fonts | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf })
$bootstrap = @{os=$osInfo; powershell=$PSVersionTable.PSVersion.ToString(); python=$selected; attempts=$attempts; tools=$tools; font_files=$foundFonts; ready=$false}
$bootstrap.blocking = @()
$bootstrap.repair_steps = @{}
if (-not $selected) {
    $bootstrap.blocking += 'python'
    $bootstrap.repair_steps.python = 'Check the WorkBuddy isolated Python environment first; otherwise open https://www.python.org/downloads/windows/ and install a suitable Python 3.9+ with pip, or pass -PythonPath to an existing executable.'
}
foreach ($name in @('ffmpeg','ffprobe')) {
    if (-not $tools[$name].file_exists) {
        $bootstrap.blocking += $name
        $bootstrap.repair_steps[$name] = "Open https://ffmpeg.org/download.html, choose a Windows EXE build, extract it, and point WB_$($name.ToUpper()) to its bin/$name.exe."
    }
}
if ($foundFonts.Count -eq 0) {
    $bootstrap.blocking += 'chinese_font'
    $bootstrap.repair_steps.chinese_font = 'Check Windows Fonts or point WB_FONT to an existing Chinese TTF/OTF/TTC font; review actual subtitle frames.'
}
$exitCode = 2
if ($selected) {
    $checkArgs = @((Join-Path $PSScriptRoot 'check_environment.py'),'--out',(Join-Path $ReportDir 'environment.json'))
    if ($RequireTranscription) { $checkArgs += @('--require-transcription','--model',$Model) }
    & $selected @checkArgs
    $exitCode = $LASTEXITCODE
    $bootstrap.ready = ($exitCode -eq 0)
} else {
    $bootstrap.next = 'Python 3.9+ executable not found. Check the WorkBuddy isolated environment, or download from https://www.python.org/downloads/windows/ with pip; supply -PythonPath for an existing interpreter. Rerun in a new report directory.'
}
$json = $bootstrap | ConvertTo-Json -Depth 10
[IO.File]::WriteAllText((Join-Path $ReportDir 'bootstrap.json'), $json, $utf8)
Write-Output $json
exit $exitCode
