import os
import unittest
from unittest.mock import patch
import check_environment


class EnvironmentGateTests(unittest.TestCase):
    def test_missing_ffmpeg_blocks_and_points_to_download(self):
        with patch.dict(os.environ, {'WB_FFMPEG': '/missing/ffmpeg.exe'}):
            report = check_environment.inspect_environment()
        self.assertFalse(report['ready'])
        self.assertIn('ffmpeg', report['blocking'])
        self.assertIn('https://ffmpeg.org/download.html', report['repair_steps']['ffmpeg'])

    def test_missing_model_blocks_only_transcription_workflow(self):
        base = check_environment.inspect_environment()
        self.assertTrue(base['ready'])
        report = check_environment.inspect_environment(require_transcription=True,
                                                       model='/missing/local-model')
        self.assertFalse(report['ready'])
        self.assertIn('transcription_model', report['blocking'])
        self.assertIn('download', report['repair_steps']['transcription_model'])
