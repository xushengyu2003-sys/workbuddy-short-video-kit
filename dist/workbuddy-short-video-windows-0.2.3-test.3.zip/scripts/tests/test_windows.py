import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
import video


class WindowsCompatibilityTests(unittest.TestCase):
    def test_custom_windows_font_directory(self):
        with tempfile.TemporaryDirectory() as td:
            font = Path(td)/'Fonts'/'msyh.ttc'
            font.parent.mkdir()
            font.write_bytes(b'test font lookup only')
            original = Path.is_file
            with patch.dict(os.environ, {'WINDIR': td, 'WB_FONT': ''}), patch.object(
                    Path, 'is_file', lambda p: original(p) if p == font else False):
                self.assertEqual(video.find_font(), str(font.resolve()))

    def test_explicit_tool_path_with_unicode_spaces(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/'中文 tools'/'ffmpeg.exe'
            path.parent.mkdir()
            path.write_bytes(b'lookup only')
            with patch.dict(os.environ, {'WB_FFMPEG': str(path)}):
                self.assertEqual(video.tool('ffmpeg'), str(path.resolve()))
            with patch.dict(os.environ, {'WB_FFMPEG': str(path)+'missing'}):
                with self.assertRaises(ValueError):
                    video.tool('ffmpeg')

    def test_utf8_child_output_and_raw_binary(self):
        result = video.run([sys.executable, '-c', "import sys; sys.stdout.buffer.write('中文诊断'.encode('utf-8'))"])
        self.assertEqual(result.stdout, '中文诊断')
        raw = video.run([sys.executable, '-c', 'import sys; sys.stdout.buffer.write(bytes([0,255,128]))'], binary=True)
        self.assertEqual(raw.stdout, bytes([0,255,128]))

    def test_cli_emits_utf8_under_ascii_console(self):
        with patch.dict(os.environ, {'PYTHONIOENCODING': 'ascii'}):
            result = subprocess.run([sys.executable, str(Path(video.__file__)), 'probe',
                                     '不存在的中文素材.mp4'], capture_output=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn('文件不存在', result.stderr.decode('utf-8'))
