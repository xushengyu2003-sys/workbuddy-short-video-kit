"""Check usable dependencies, not just installed package names. No downloads."""
import argparse
import json
import platform
from pathlib import Path
import subprocess
import sys
import video


def check_child(code, *args, timeout=25):
    try:
        p = subprocess.run([sys.executable, '-c', code, *args], capture_output=True,
                           encoding='utf-8', errors='replace', timeout=timeout)
        return {'ok': p.returncode == 0, 'detail': (p.stdout if p.returncode == 0 else p.stderr)[-3000:].strip()}
    except (OSError, subprocess.TimeoutExpired) as e:
        return {'ok': False, 'detail': str(e)}


def inspect_environment(require_transcription=False, model='small'):
    checks = {}
    checks['python'] = {'ok': sys.version_info >= (3, 9), 'path': sys.executable, 'version': platform.python_version()}
    checks['pip'] = check_child('import pip; print(pip.__version__)')
    checks['venv'] = check_child('import venv, ensurepip; print("available")')
    for name in ['ffmpeg', 'ffprobe']:
        try:
            path = video.tool(name)
            p = subprocess.run([path, '-version'], capture_output=True, encoding='utf-8', errors='replace', timeout=15)
            checks[name] = {'ok': p.returncode == 0, 'path': path, 'detail': (p.stdout or p.stderr).splitlines()[0]}
        except (ValueError, OSError, IndexError, subprocess.TimeoutExpired) as e:
            checks[name] = {'ok': False, 'detail': str(e)}
    try:
        # Confirm that the executable can actually encode H.264 + AAC, not just list them.
        p = subprocess.run([video.tool('ffmpeg'), '-v', 'error', '-nostdin',
                            '-f', 'lavfi', '-i', 'color=s=128x128:r=10:d=0.2',
                            '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo',
                            '-t', '0.2', '-c:v', 'libx264', '-threads', '1', '-c:a', 'aac',
                            '-f', 'mpegts', 'pipe:1'], capture_output=True, timeout=20)
        checks['h264_aac'] = {'ok': p.returncode == 0 and bool(p.stdout), 'detail': p.stderr.decode('utf-8', errors='replace')[-3000:]}
    except (ValueError, OSError, subprocess.TimeoutExpired) as e:
        checks['h264_aac'] = {'ok': False, 'detail': str(e)}
    checks['Pillow'] = check_child('import PIL; from PIL import Image, ImageFont; print(PIL.__version__)')
    try:
        font = video.find_font()
        check = check_child('from PIL import ImageFont; import sys; f=ImageFont.truetype(sys.argv[1],32); print(f.getbbox("中文测试"))', font)
        checks['chinese_font'] = dict(check, path=font, visual_glyph_review='pending')
    except (ValueError, OSError) as e:
        checks['chinese_font'] = {'ok': False, 'detail': str(e)}
    if require_transcription:
        checks['faster_whisper'] = check_child('import faster_whisper, ctranslate2; print(faster_whisper.__version__); print(ctranslate2.__version__)')
        if checks['faster_whisper']['ok']:
            checks['transcription_model'] = check_child(
                'from faster_whisper import WhisperModel; import sys; WhisperModel(sys.argv[1],device="cpu",compute_type="int8",local_files_only=True,cpu_threads=2); print("local CPU model loaded")',
                model, timeout=60)
        else:
            checks['transcription_model'] = {'ok': False, 'detail': 'Dependency import failed; model was not loaded'}
    required = ['python', 'ffmpeg', 'ffprobe', 'h264_aac', 'Pillow', 'chinese_font']
    if require_transcription:
        required += ['faster_whisper', 'transcription_model']
    fixes = {
        'python': 'First check the WorkBuddy isolated Python environment; otherwise download a suitable Python 3.9+ for Windows from https://www.python.org/downloads/windows/, install with pip and rerun with -PythonPath if needed.',
        'ffmpeg': 'Open https://ffmpeg.org/download.html, choose a Windows EXE build and extract it; put ffmpeg.exe on PATH or set WB_FFMPEG to its full path.',
        'ffprobe': 'From the same FFmpeg Windows build at https://ffmpeg.org/download.html, put ffprobe.exe on PATH or set WB_FFPROBE.',
        'h264_aac': 'Get an FFmpeg Windows build linked at https://ffmpeg.org/download.html that can encode libx264 and AAC.',
        'Pillow': 'See https://pypi.org/project/Pillow/; in the selected project Python run python -m pip install "Pillow>=10,<13".',
        'chinese_font': 'Set WB_FONT to a readable local Chinese TTF/OTF/TTC font, then review rendered glyphs.',
        'faster_whisper': 'See https://pypi.org/project/faster-whisper/; in the selected project Python run python -m pip install "faster-whisper>=1.1,<2"; retain DLL errors if import fails.',
        'transcription_model': 'Give --model a valid local model directory; if needed, explain the download and ask the user, then run scripts/prepare_model.py --model small --allow-download --out NEW_REPORT.json and recheck. The checker never downloads.',
    }
    missing = [key for key in required if not checks[key]['ok']]
    return {'platform': platform.platform(), 'runtime_python': sys.executable,
            'require_transcription': require_transcription, 'model': model if require_transcription else None,
            'ready': not missing, 'checks': checks, 'blocking': missing,
            'repair_steps': {key: fixes[key] for key in missing},
            'install_support_missing': [key for key in ['pip', 'venv'] if not checks[key]['ok']],
            'install_support_steps': 'If pip or venv is missing, install a full Python distribution from https://www.python.org/downloads/windows/ and recheck before creating a project environment.'}


def main():
    video.configure_console()
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', required=True)
    p.add_argument('--require-transcription', action='store_true')
    p.add_argument('--model', default='small')
    a = p.parse_args()
    if Path(a.out).exists():
        p.error('Report exists; choose a new path')
    report = inspect_environment(a.require_transcription, a.model)
    video.write_json(a.out, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['ready'] else 2


if __name__ == '__main__':
    sys.exit(main())
